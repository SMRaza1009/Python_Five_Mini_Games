import random

print("=============================")

print("Welcome to All of Games!")

print("=============================")

def  quiz_game():
    print("Welcome to Computer Quiz Game!")

    playing = input("Do you want to play? (yes/no) ").lower()
    count = 0
    score = 0

    if playing.lower()!='yes':
        quit()
    else:
        print("Okay! Let's play :) ")
        
        count += 1
        question_1 = input("What does CPU stands for ? ")
        if question_1.lower()=="central processing unit":
            print("Correct!")
            score +=1
        else:
            print("Incorrect!") 
        
        count += 1
        question_2 = input("What does GPU stands for ? ")
        if question_2.lower()=="graphics processing unit":
            print("Correct!")
            score +=1
        else:
            print("Incorrect!")
        
        count += 1
        question_3 = input("What does AI stands for ? ")
        if question_3.lower()=="artificial intelligence":
            print("Correct!")
            score +=1
        else:
            print("Incorrect!")
            
        count += 1
        question_4 = input("What does ML stands for ? ")
        if question_4.lower()=="machine learning":
            print("Correct!")
            score +=1
        else:
            print("Incorrect!")               
        
        count += 1
        question_5 = input("What does DL stands for ? ")
        if question_5.lower()=="deep learning":
            print("Correct!")
            score +=1
        else:
            print("Incorrect!")    
        
        count += 1    
        question_6 = input("What does RAM stands for ? ")
        if question_6.lower()=="random access memory":
            print("Correct!")
            score +=1
        else:
            print("Incorrect!")
        
        count += 1
        question_7 = input("What does ROM stands for ? ")
        if question_7.lower()=="read only memory":
            print("Correct!")
            score +=1
        else:
            print("Incorrect!") 
                
        count += 1    
        question_8 = input("What does PSU stands for ? ")
        if question_8.lower()=="power supply":
            print("Correct!")
            score +=1  
        else:
            print("Incorrect!")
            
        print("Your score is : "+ str(score) + "/"+ str(count))    
        print("Your got : "+ str(score / count * 100) + "%")    
    



def number_guessing_game():
    top_of_range = input("Type a number: ")
    guesses = 0
    if top_of_range.isdigit():
        top_of_range = int(top_of_range)
        
        if top_of_range <=0:
            print("Please enter a number above than 0 next time.")
            quit()            
    else:
        print("Please type a number next time.")
        quit()

    random_number = random.randint(0, top_of_range)
        
    while True:
        guesses +=1
        user_guess = input("Make a guess number: ")
        if user_guess.isdigit():
            user_guess = int(user_guess)
        else:
            print("Please enter a number next time. ")
            continue    
        if user_guess == random_number:
            print("You got it!")
            break
        elif user_guess > random_number:
            
            print("You were above the number of guesses.")
        else:
            print("You were below the number")        
    print("You got it in, ",str(guesses)," guesses")
    

def rock_paper_scissor():
    user_win = 0
    computer_win = 0
    options = ["rock", "paper","scissors"]
    while True:
        user_input = input("Type Rock/Paper/Scissors or Q to quit : ").lower()
        if user_input =="q":
            break
        
        if user_input not in options:
            continue    
            
        random_number = random.randint(0,2)
        
        computer_pick = options[random_number] 
        print("Computer picked", computer_pick +".")
        
        if user_input == "rock" and computer_pick=="scissors":
            print("You win")
            user_win+=1
            
        elif user_input == "paper" and computer_pick=="rock":
            print("You win")
            user_win+=1
        
        elif user_input == "scissors" and computer_pick=="paper":
            print("You win")
            user_win+=1
        
        else:
            print("You lost!")
            computer_win+=1
            
    print("You won ", str(user_win)+" times.")
    print("The computer won ", str(computer_win)+" times.")
            
    print("Good bye!")
    

def choose_your_adventure():
    name = input("Type your name: ")
    print("Welcome", name, "to this adventure!")

    ans = input("Your are on dirt road, it has come to an end and you can go left or right. Which way would you like to go left?").lower()
    
    if ans =='left':
        ans = input("You come to a river, you can walk around it or swim accross? Type walk to walk around and swim to swim accross:   ")
        
        if ans == 'swim':
            print("You swam accross the river and were eaten by alligator.")
        
        elif ans == 'walk':
            print("You walk for many miles, ran out of water and you lost the game. ")
        
        else:
            print("Not a valid option. You lose")           
        
    elif ans == "right":
        ans = input ("You can go back and lose.")
        
        if ans == 'back ':
            print("You swam accross the river and were eaten by alligator.")
        
        elif ans == 'cross':
            ans = input("You cross the bridge and meet a stranger. Dp you want to talk them (yes/no)?")
            
            if ans == 'yes':
                print("You talk to the stranger and they give you gold. You WIN!")
                
            elif ans == 'no':
                print("You ignore the stranger and they are offened and you LOSE!")
            else:
                print("Not a valid option. You lose")
            
        else:
            print("Not a valid option. You lose")

    else:
        print("Not a valid option. You lose")    
            
    print("Thank you for trying", name)        



game_input = input("Which game do you want to play? \nPress 1 for QUIZ GAME \nPress 2 for NUMBER GUESSING GAME \nPress 3 for ROCK PAPER SCISSOR \nPress 4 for CHOOSE YOUR OWN ADVENTURE \n")

while True:
    if game_input == '1':
        quiz_game()
        print("=============================")
        another_game = input("Do you want to play another game? (yes/no): ").lower()
        if another_game == 'no':
            quit()
        elif another_game == 'yes':
            game_input = input("Which game do you want to play? \nPress 1 for QUIZ GAME \nPress 2 for NUMBER GUESSING GAME \nPress 3 for ROCK PAPER SCISSOR \nPress 4 for CHOOSE YOUR OWN ADVENTURE \n")
        else:
            print("You enter wrong input.")
            quit() 
              
    elif game_input == '2':
        number_guessing_game()
        print("=============================")
        another_game = input("Do you want to play another game? (yes/no): ").lower()
        if another_game == 'no':
            quit()
        elif another_game == 'yes':
            game_input = input("Which game do you want to play? \nPress 1 for QUIZ GAME \nPress 2 for NUMBER GUESSING GAME \nPress 3 for ROCK PAPER SCISSOR \nPress 4 for CHOOSE YOUR OWN ADVENTURE \n")
        else:
            print("You enter wrong input.")
            quit()
            
    elif game_input == '3':
        rock_paper_scissor()
        print("=============================")
        another_game = input("Do you want to play another game? (yes/no): ").lower()
        if another_game == 'no':
            quit()
        elif another_game == 'yes':
            game_input = input("Which game do you want to play? \nPress 1 for QUIZ GAME \nPress 2 for NUMBER GUESSING GAME \nPress 3 for ROCK PAPER SCISSOR \nPress 4 for CHOOSE YOUR OWN ADVENTURE \n")
        else:
            print("You enter wrong input.")
            quit()
            
    elif game_input == '4':
        choose_your_adventure()
        print("=============================")
        another_game = input("Do you want to play another game? (yes/no): ").lower()
        if another_game == 'no':
            quit()
        elif another_game == 'yes':
            game_input = input("Which game do you want to play? \nPress 1 for QUIZ GAME \nPress 2 for NUMBER GUESSING GAME \nPress 3 for ROCK PAPER SCISSOR \nPress 4 for CHOOSE YOUR OWN ADVENTURE \n")
        else:
            print("You enter wrong input.")
            quit()
    else:
        print("You enter invalid number!")    
                

