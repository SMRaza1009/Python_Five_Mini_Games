name = input("Type your name: ")
print("Welcome", name, "to this adventure!")

ans = input("Your are on dirt road, it has come to an end and you can go left or right. Which way would you like to go left?").lower()
 
if ans =='left':
    ans = input("You come to a river, you can walk around it or swim accross? Type walk to walk around and swim to swim accross:   ")
    
    if ans == 'swim':
       print("You swam accross the river and were eaten by alligator.")
    
    elif ans == 'walk':
        print("You walk for many miles, ran out of water and you lost the game. ")
    
    else:
        print("Not a valid option. You lose")           
    
elif ans == "right":
    ans = input ("You can go back and lose.")
    
    if ans == 'back ':
           print("You swam accross the river and were eaten by alligator.")
    
    elif ans == 'cross':
        ans = input("You cross the bridge and meet a stranger. Dp you want to talk them (yes/no)?")
        
        if ans == 'yes':
            print("You talk to the stranger and they give you gold. You WIN!")
            
        elif ans == 'no':
            print("You ignore the stranger and they are offened and you LOSE!")
        else:
            print("Not a valid option. You lose")
         
    else:
        print("Not a valid option. You lose")

else:
    print("Not a valid option. You lose")    
        
print("Thank you for trying", name)        