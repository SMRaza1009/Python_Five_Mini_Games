print("Welcome to Computer Quiz Game!")

playing = input("Do you want to play? ")
count = 0
score = 0

if playing.lower()!='yes':
    quit()
else:
    print("Okay! Let's play :) ")
    
    count += 1
    question_1 = input("What does CPU stands for ? ")
    if question_1.lower()=="central processing unit":
        print("Correct!")
        score +=1
    else:
        print("Incorrect!") 
    
    count += 1
    question_2 = input("What does GPU stands for ? ")
    if question_2.lower()=="graphics processing unit":
        print("Correct!")
        score +=1
    else:
        print("Incorrect!")
    
    count += 1
    question_3 = input("What does AI stands for ? ")
    if question_3.lower()=="artificial intelligence":
        print("Correct!")
        score +=1
    else:
        print("Incorrect!")
        
    count += 1
    question_4 = input("What does ML stands for ? ")
    if question_4.lower()=="machine learning":
        print("Correct!")
        score +=1
    else:
        print("Incorrect!")               
    
    count += 1
    question_5 = input("What does DL stands for ? ")
    if question_5.lower()=="deep learning":
        print("Correct!")
        score +=1
    else:
        print("Incorrect!")    
    
    count += 1    
    question_6 = input("What does RAM stands for ? ")
    if question_6.lower()=="random access memory":
        print("Correct!")
        score +=1
    else:
        print("Incorrect!")
    
    count += 1
    question_7 = input("What does ROM stands for ? ")
    if question_7.lower()=="read only memory":
        print("Correct!")
        score +=1
    else:
        print("Incorrect!") 
               
    count += 1    
    question_8 = input("What does PSU stands for ? ")
    if question_8.lower()=="power supply":
        print("Correct!")
        score +=1  
    else:
        print("Incorrect!")
        
    print("Your score is : "+ str(score) + "/"+ str(count))    
    print("Your got : "+ str(score / count * 100) + "%")    
    
            
   